/**
 * Created on 2015. 3. 8.
 * @author cskim -- hufs.ac.kr, Dept of CSE
 * Copy Right -- Free for Educational Purpose
 */
package hufs.ces.grimpan.core;

/**
 * @author cskim
 *
 */
public class Utils {

	public static final int SHAPE_LINE = 0;
	public static final int SHAPE_PENCIL = 1;
	public static final int EDIT_MOVE = 2;
	public static final int EDIT_DELETE = 3;
	public static final int EDIT_UNDO = 4;
	
	public static final String DEFAULT_DIR = "C:/Temp/";
	
	public static final int MINPOLYDIST = 6;

}
